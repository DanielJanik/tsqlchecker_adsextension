'use strict';
// The module 'vscode' contains the VS Code extensibility API
// Import the module and reference it with the alias vscode in your code below
import * as vscode from 'vscode';

// The module 'azdata' contains the Azure Data Studio extensibility API
// This is a complementary set of APIs that add SQL / Data-specific functionality to the app
// Import the module and reference it with the alias azdata in your code below

import * as azdata from 'azdata';
import { debug } from 'util';
import { start } from 'repl';


//export function activate(context: vscode.ExtensionContext) {
    //console.log('Congratulations, your extension "tsqlchecker" is now active!');
    //context.subscriptions.push(vscode.commands.registerCommand('extension.sayHello', () => {
        //vscode.window.showInformationMessage('Hello World!');
    //}));

    //context.subscriptions.push(vscode.commands.registerCommand('extension.showCurrentConnection', () => {
      
        //azdata.connection.getCurrentConnection().then(connection => {
          //  let connectionId = connection ? connection.connectionId : 'No connection found!';
          //  vscode.window.showInformationMessage(connectionId);
        //}, error => {
        //     console.info(error);
        //});
    //}));
//}

// this method is called when your extension is activated
// your extension is activated the very first time the command is executed
export function activate(context: vscode.ExtensionContext) {

	console.log('decorator sample is activated');

	let timeout: NodeJS.Timer | undefined = undefined;
	// create a decorator type that we use to decorate small numbers

	const smallNumberDecorationType = vscode.window.createTextEditorDecorationType({
		borderWidth: '1px',
		borderStyle: 'solid',
		overviewRulerColor: 'blue',
		overviewRulerLane: vscode.OverviewRulerLane.Right,
		light: {
			// this color will be used in light color themes
			borderColor: 'darkblue'
		},
		dark: {
			// this color will be used in dark color themes
			borderColor: 'lightblue'
		}
	});

	// create a decorator type that we use to decorate large numbers
	const largeNumberDecorationType = vscode.window.createTextEditorDecorationType({
		cursor: 'crosshair',
		// use a themable color. See package.json for the declaration and default values.
		backgroundColor: { id: 'myextension.largeNumberBackground' }
	});

	let activeEditor = vscode.window.activeTextEditor;

	function updateDecorations() {
		if (!activeEditor) {
			return;
		}

        /*
		const regEx = /\d+/g;
		const text = activeEditor.document.getText();
		const smallNumbers: vscode.DecorationOptions[] = [];
		const largeNumbers: vscode.DecorationOptions[] = [];

        let match;

		while (match = regEx.exec(text)) {
			const startPos = activeEditor.document.positionAt(match.index);
			const endPos = activeEditor.document.positionAt(match.index + match[0].length);
			const decoration = { range: new vscode.Range(startPos, endPos), hoverMessage: 'Number **' + match[0] + '**' };

			if (match[0].length < 3) {
				smallNumbers.push(decoration);
			} else {
				largeNumbers.push(decoration);
			}
		}
		activeEditor.setDecorations(smallNumberDecorationType, smallNumbers);
        activeEditor.setDecorations(largeNumberDecorationType, largeNumbers);
        */
       
        //get all comments to compare later if needed
        const regEx = /\/\*[\s\S]*?\*\/|([^:]|^)\-\-.*$/g;
        const text = activeEditor.document.getText();
        const mydecoration: vscode.DecorationOptions[] = [];

        //get document text and remove all comments (may not be used/needed)
        var sqltext = activeEditor.document.getText();
        sqltext = sqltext.replace(/\/\*[\s\S]*?\*\/|([^:]|^)\-\-.*$/g, "");

        var comment_tuple = [];
        var i = 0;

        let match;

        //get all the comments
        while (match = regEx.exec(text)) {
            const startPos = activeEditor.document.positionAt(match.index);
            const endPos = activeEditor.document.positionAt(match.index + match[0].length);
            comment_tuple[i] = [startPos, endPos];
            i += 1;
        }

        //now let's look for issues but not inside the comments
        //OR let's  get all the issues and then compare their tuple with the comment tuple?
        
        //regex for "SELECT * FROM"
        const regExSelStar = /(\*,|,\*|, \*|select\s+\*\s+from|select\*\s+from|select\s+\*from|select\*from)/gim;

        while (match = regExSelStar.exec(text)) {
            const startPos = activeEditor.document.positionAt(match.index);
            const endPos = activeEditor.document.positionAt(match.index + match[0].length);
            const decoration = { range: new vscode.Range(startPos, endPos), hoverMessage: 'SELECT * is bad practice. This can result in poor data access due to lack of indexes' };
            
            mydecoration.push(decoration);
        }

        // //find all with where then compare to all 
        // const regExNoWhere = /select\s+(.*?)\s*from\s+(.*?)\s*(where\s(.*?)\s*)/g;
        // const regExAllSelect = /select\s+(.*?)\s*from/g;

        // while (match = regExSelStar.exec(text)) {
        //     const startPos = activeEditor.document.positionAt(match.index);
        //     const endPos = activeEditor.document.positionAt(match.index + match[0].length);
        //     const decoration = { range: new vscode.Range(startPos, endPos), hoverMessage: 'SELECT * is bad practice. This can result in poor data access due to lack of indexes' };
            
        //     mydecoration.push(decoration);

        //     //comment_tuple[i] = [startPos, endPos];
        //     i += 1;
        // }

        const regExHints = /with\s+\(([^)]+)\)/gi;

        while (match = regExHints.exec(text)) {
            const regExHint = /holdlock|xlock|tablock|tablockx|paglock|rowlock|nolock/gi;

            while (match = regExHint.exec(text)) {
                const startPos = activeEditor.document.positionAt(match.index);
                const endPos = activeEditor.document.positionAt(match.index + match[0].length);
                
                var msg;

                switch (match[0].trim().toLowerCase()) {
                    case "holdlock":
                        msg = "HOLDLOCK sets 'serializable isolation' which reduces concurrency & performance but adds 'key range locks'";
                        break;
                    case "xlock":
                        msg = "XLOCK forces an exclusive lock!";
                        break;
                    case "tablock":
                        msg = "TABLOCK promotes locks for this resource to a table lock. This could cause serious performance problems";
                        break;
                    case "tablockx":
                        msg = "TABLOCKX promotes locks for this resource to an exclusive table lock. This could cause serious performance problems";
                        break;
                    case "paglock":
                        msg = "PAGLOCK may take page locks in place of individual row locks. This is more of a suggestion so don't count on it ;)";
                        break;
                    case "rowlock":
                        msg = "ROWLOCK may take row locks in place of page locks. This can cause additional overhead for the sql engine and is not recommended.";
                        break;
                    case "nolock":
                        msg = "NOLOCK is like the duct tape of SQL Server. By setting this hint the query can return dirty data. Be sure your data doesn't matter.";
                        break;
                    default:
                        console.log("missing a hint?");
                        break;
                }

                const decoration = { range: new vscode.Range(startPos, endPos), hoverMessage: msg };
                mydecoration.push(decoration);
            }
        }
        
        const regExJoinHints = /(loop\s+join|hash\s+join|merge\s+join|remote\s+join)/gim;

        while (match = regExJoinHints.exec(text)) {
            const startPos = activeEditor.document.positionAt(match.index);
            const endPos = activeEditor.document.positionAt(match.index + match[0].length);
            const decoration = { range: new vscode.Range(startPos, endPos), hoverMessage: "Using join hints can seriously reduce performance, either immdiately or overtime as data changes. This hint is not recommended." };
            mydecoration.push(decoration);
        }

        activeEditor.setDecorations(smallNumberDecorationType, mydecoration);

        //    if (text.length == 0)
        //    {
        //    }
       
	}

	function triggerUpdateDecorations() {
		if (timeout) {

			clearTimeout(timeout);
			timeout = undefined;
		}
		timeout = setTimeout(updateDecorations, 500);
	}

	if (activeEditor) {
		triggerUpdateDecorations();
	}

	vscode.window.onDidChangeActiveTextEditor(editor => {
		activeEditor = editor;
		if (editor) {
			triggerUpdateDecorations();
		}
	}, null, context.subscriptions);

	vscode.workspace.onDidChangeTextDocument(event => {
		if (activeEditor && event.document === activeEditor.document) {
			triggerUpdateDecorations();
		}
	}, null, context.subscriptions);
}

// this method is called when your extension is deactivated
export function deactivate() {
}